to use:
extract to your dolphin user folder and merge the folders
depending on the dolphin build you are using, your \User folder should be located in either the dolphin folder itself, or "my documents"
go into dolphin's graphic settings under the advanced tab and enable "load custom textures" 
select shikamaru's alternate color