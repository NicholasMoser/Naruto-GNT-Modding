Same texture but without mask, replace image with same name in load directory.
(make sure to save other image somewhere else if you want to use it again) 