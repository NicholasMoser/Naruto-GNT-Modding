Directory should be (5.9 beta or whatever dolphin you're running)

FM-v5.9-BETA > User > Load  > Textures > G4NJDA > Chr > kakashi

Thanks @mom666