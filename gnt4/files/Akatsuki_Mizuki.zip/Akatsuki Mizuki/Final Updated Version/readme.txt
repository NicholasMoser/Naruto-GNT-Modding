Directory should be (5.9 beta or whatever dolphin you're running)

FM-v5.9-BETA > User > Load  > Textures > G4NJDA > Chr > Mizuki

Thanks @mom666

Update: 
Cleaned Texture and added
Sharingan eye on all eye frames

Removed Fangs (did not sync with speech animations)