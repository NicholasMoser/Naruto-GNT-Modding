Directory should be (5.9 beta or whatever dolphin you're running)

FM-v5.9-BETA > User > Load  > Textures > G4NJDA > Chr > Mizuki

Thanks @mom666

Update: 
Cleaned Texture and added
Sharingan eye
 (single frame only, comes into view when looking stright ahead)
 (Remove eyes texture to return eyes to normal) 
