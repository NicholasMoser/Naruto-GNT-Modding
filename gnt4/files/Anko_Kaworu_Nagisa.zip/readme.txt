to use:
extract to your dolphin user folder and merge the folders
depending on the dolphin build you are using, your \User folder should be located in either the dolphin folder itself, or "my documents"
go into dolphin's graphic settings under the advanced tab and enable "load custom textures" 
select anko

to restore default eye color:
remove the files named:
tex1_128x64_0b0ca9e49b133bbe_14.dds
tex1_128x64_4fca9998c5bab2ac_14.dds
tex1_128x64_2900d9762045ede0_14.dds
tex1_128x64_35378cf5c0adeb2b_14.dds
tex1_128x64_689035f0ec2f7c8b_14.dds
tex1_128x64_33431367b9c27d93_14.dds
tex1_128x64_c5141a05a05f64ac_14.dds
tex1_128x64_eb96ec683eb45467_14.dds